# ELPOP لأندرويد — المصدر

هذا مشروع Android خفيف يعيد بناء غلاف WebView للتطبيق. يفتح `https://star-ruby-blue-spark.grok.me/`، مع واجهة عربية وأدوات متابعة تحميل ومعالجة اتصال أساسية. يعتمد محتوى التطبيق على خدمة Grok ويتطلب اتصالاً بالإنترنت وحساباً/تسجيل دخول عند طلب الموقع.

## البناء محلياً

يتطلب JDK 17 أو أحدث، Gradle 8.7، Android SDK Platform 35 وBuild Tools 35.0.0. اضبط `ANDROID_HOME` أو حدّث `local.properties`، ثم نفّذ `gradle assembleDebug`. يخرج APK debug في `app/build/outputs/apk/debug/app-debug.apk`.

المعرّف `com.elpop.studio` ونسخة Android الدنيا API 23. البناء الحالي Debug وليس إعداد توقيع للنشر في Google Play. لم يُرفق كود الموقع الأصلي، ولم يتسن الوصول إلى محتواه المحمي بعد تسجيل الدخول.
